<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Kiểm tra người dùng đã đăng nhập và có role 2 (Quản lý tổ chức)
if (!isset($_SESSION['user']) || $_SESSION['user']['ID_Role'] != 2) {
    header('Location: ../login.php');
    exit;
}

// Lấy tất cả kế hoạch với phân công nhân viên
try {
    $pdo = getDBConnection();
    $stmt = $pdo->query("
        SELECT 
            kht.ID_KeHoach,
            kht.TenKeHoach,
            kht.NoiDung,
            kht.NgayBatDau,
            kht.NgayKetThuc,
            kht.TrangThai,
            kht.ID_NhanVien,
            nv.HoTen AS TenNhanVien,
            nv.ChucVu,
            nv.SoDienThoai,
            COALESCE(u.OnlineStatus, 'Offline') AS OnlineStatus,
            dl.TenSuKien,
            dd.TenDiaDiem,
            dd.DiaChi,
            s.ID_SuKien
        FROM kehoachthuchien kht
        LEFT JOIN nhanvieninfo nv ON kht.ID_NhanVien = nv.ID_NhanVien
        LEFT JOIN users u ON nv.ID_User = u.ID_User
        LEFT JOIN sukien s ON kht.ID_SuKien = s.ID_SuKien
        LEFT JOIN datlichsukien dl ON s.ID_DatLich = dl.ID_DatLich
        LEFT JOIN diadiem dd ON dl.ID_DD = dd.ID_DD
        ORDER BY kht.NgayBatDau ASC
    ");
    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Lấy tất cả nhân viên
    $stmt = $pdo->query("
        SELECT 
            nv.ID_NhanVien,
            nv.HoTen,
            nv.ChucVu,
            nv.SoDienThoai,
            u.OnlineStatus
        FROM nhanvieninfo nv
        JOIN users u ON nv.ID_User = u.ID_User
        WHERE u.TrangThai = 'Hoạt động'
        ORDER BY nv.HoTen
    ");
    $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $plans = [];
    $staff = [];
    error_log("Error fetching plans and staff: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phân công nhân viên - Quản lý sự kiện</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .assignment-card {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .assignment-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .plan-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 10px 10px 0 0;
        }
        .staff-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
        }
        .staff-assigned {
            background: #d4edda;
            border-left: 4px solid #28a745;
        }
        .staff-unassigned {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .status-pending {
            background: #e9ecef;
            color: #495057;
        }
        .status-in-progress {
            background: #fff3cd;
            color: #856404;
        }
        .status-completed {
            background: #d4edda;
            color: #155724;
        }
        .online-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        .online {
            background: #28a745;
        }
        .offline {
            background: #6c757d;
        }
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #667eea;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -23px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #667eea;
            border: 3px solid white;
        }
        .timeline-item.assigned::before {
            background: #28a745;
        }
        .timeline-item.unassigned::before {
            background: #ffc107;
        }
    </style>
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-header mb-4">
                    <h1 class="page-title">
                        <i class="fas fa-users-cog"></i>
                        Phân công nhân viên
                    </h1>
                    <p class="page-subtitle">Quản lý và phân công nhân viên cho các kế hoạch thực hiện</p>
            </div>
            
                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <h3 class="text-primary"><?= count($plans) ?></h3>
                                <p class="text-muted mb-0">Tổng kế hoạch</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <h3 class="text-success"><?= count(array_filter($plans, function($p) { return !empty($p['ID_NhanVien']); })) ?></h3>
                                <p class="text-muted mb-0">Đã phân công</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <h3 class="text-warning"><?= count(array_filter($plans, function($p) { return empty($p['ID_NhanVien']); })) ?></h3>
                                <p class="text-muted mb-0">Chưa phân công</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <h3 class="text-info"><?= count($staff) ?></h3>
                                <p class="text-muted mb-0">Tổng nhân viên</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="fas fa-plus-circle"></i>
                                    Tạo lịch làm việc nhanh
                                </h5>
                            </div>
                            <div class="card-body">
                                <button class="btn btn-primary" onclick="showCreateScheduleModal()">
                                    <i class="fas fa-calendar-plus"></i>
                                    Tạo lịch làm việc mới
                                </button>
                                <p class="text-muted mt-2 mb-0">
                                    <small>Tạo công việc trực tiếp cho nhân viên mà không cần qua kế hoạch</small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Plans List -->
                <div class="row">
                    <?php foreach ($plans as $plan): ?>
                    <div class="col-lg-6 col-xl-4 mb-4">
                        <div class="assignment-card">
                            <div class="plan-header">
                                <h5 class="mb-2">
                                    <i class="fas fa-tasks"></i>
                                    <?= htmlspecialchars($plan['ten_kehoach']) ?>
                                </h5>
                                <p class="mb-1">
                                    <i class="fas fa-calendar"></i>
                                    <?= date('d/m/Y', strtotime($plan['NgayBatDau'])) ?> - 
                                    <?= date('d/m/Y', strtotime($plan['NgayKetThuc'])) ?>
                                </p>
                                <?php if ($plan['TenSuKien']): ?>
                                <p class="mb-0">
                                    <i class="fas fa-calendar-check"></i>
                                    <?= htmlspecialchars($plan['TenSuKien']) ?>
                                </p>
                                <?php endif; ?>
                        </div>
                            
                            <div class="card-body">
                                <div class="mb-3">
                                    <p class="text-muted"><?= htmlspecialchars($plan['NoiDung']) ?></p>
                </div>
                
                                <?php if ($plan['TenDiaDiem']): ?>
                                <div class="mb-3">
                                    <p class="mb-1">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <strong>Địa điểm:</strong> <?= htmlspecialchars($plan['TenDiaDiem']) ?>
                                    </p>
                                    <p class="mb-0 text-muted"><?= htmlspecialchars($plan['DiaChi']) ?></p>
                    </div>
                                <?php endif; ?>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $plan['TrangThai'])) ?>">
                                        <?= htmlspecialchars($plan['TrangThai']) ?>
                                    </span>
                        </div>
                        
                                <!-- Staff Assignment -->
                                <div class="staff-info <?= $plan['ID_NhanVien'] ? 'staff-assigned' : 'staff-unassigned' ?>">
                                    <?php if ($plan['ID_NhanVien']): ?>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">
                                                <span class="online-indicator <?= $plan['OnlineStatus'] == 'Online' ? 'online' : 'offline' ?>"></span>
                                                <?= htmlspecialchars($plan['TenNhanVien']) ?>
                                            </h6>
                                            <p class="mb-1 text-muted">
                                                <i class="fas fa-briefcase"></i>
                                                <?= htmlspecialchars($plan['ChucVu']) ?>
                                            </p>
                                            <p class="mb-0 text-muted">
                                                <i class="fas fa-phone"></i>
                                                <?= htmlspecialchars($plan['SoDienThoai']) ?>
                                            </p>
                                        </div>
                                        <div class="text-end">
                                            <button class="btn btn-outline-danger btn-sm" onclick="removeAssignment(<?= $plan['ID_KeHoach'] ?>)">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="text-center">
                                        <p class="mb-2 text-muted">Chưa phân công nhân viên</p>
                                        <button class="btn btn-primary btn-sm" onclick="assignStaff(<?= $plan['ID_KeHoach'] ?>)">
                                            <i class="fas fa-user-plus"></i>
                                            Phân công
                                        </button>
                </div>
                                    <?php endif; ?>
                        </div>
                    </div>
                </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if (empty($plans)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                    <h3>Chưa có kế hoạch nào</h3>
                    <p class="text-muted">Các kế hoạch thực hiện sẽ hiển thị ở đây để phân công nhân viên.</p>
                    <a href="event-planning.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Tạo kế hoạch mới
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Assign Staff Modal -->
    <div class="modal fade" id="assignStaffModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-user-plus"></i>
                        Phân công nhân viên
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="assignStaffForm">
                        <input type="hidden" id="planId" name="planId">
                        
                                <div class="mb-3">
                            <label for="staffSelect" class="form-label">Chọn nhân viên *</label>
                            <select class="form-select" id="staffSelect" name="staffId" required>
                                        <option value="">Chọn nhân viên</option>
                                <?php foreach ($staff as $s): ?>
                                <option value="<?= $s['ID_NhanVien'] ?>" data-phone="<?= htmlspecialchars($s['SoDienThoai']) ?>" data-status="<?= $s['OnlineStatus'] ?>">
                                    <?= htmlspecialchars($s['HoTen']) ?> - <?= htmlspecialchars($s['ChucVu']) ?>
                                    <?= $s['OnlineStatus'] == 'Online' ? ' (Online)' : ' (Offline)' ?>
                                </option>
                                <?php endforeach; ?>
                                    </select>
                                </div>
                        
                        <div id="staffInfo" class="alert alert-info" style="display: none;">
                            <h6>Thông tin nhân viên:</h6>
                            <p id="staffDetails"></p>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" onclick="saveAssignment()">
                        <i class="fas fa-save"></i>
                        Phân công
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Schedule Modal -->
    <div class="modal fade" id="createScheduleModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-calendar-plus"></i>
                        Tạo lịch làm việc mới
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="createScheduleForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="scheduleStaff" class="form-label">Nhân viên *</label>
                                    <select class="form-select" id="scheduleStaff" name="staff_id" required>
                                        <option value="">Chọn nhân viên</option>
                                        <?php foreach ($staff as $s): ?>
                                        <option value="<?= $s['ID_NhanVien'] ?>">
                                            <?= htmlspecialchars($s['HoTen']) ?> - <?= htmlspecialchars($s['ChucVu']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="scheduleEvent" class="form-label">Sự kiện</label>
                                    <select class="form-select" id="scheduleEvent" name="event_id">
                                        <option value="">Chọn sự kiện (tùy chọn)</option>
                                        <?php
                                        // Lấy các sự kiện đã duyệt
                                        try {
                                            $stmt = $pdo->query("
                                                SELECT dl.ID_DatLich, dl.TenSuKien, dl.NgayBatDau, dl.NgayKetThuc
                                                FROM datlichsukien dl
                                                WHERE dl.TrangThaiDuyet = 'Đã duyệt'
                                                ORDER BY dl.NgayBatDau DESC
                                                LIMIT 20
                                            ");
                                            $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($events as $event):
                                        ?>
                                        <option value="<?= $event['ID_DatLich'] ?>">
                                            <?= htmlspecialchars($event['TenSuKien']) ?> 
                                            (<?= date('d/m/Y', strtotime($event['NgayBatDau'])) ?>)
                                        </option>
                                        <?php endforeach; ?>
                                        <?php } catch (Exception $e) { } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="scheduleTask" class="form-label">Nhiệm vụ *</label>
                            <input type="text" class="form-control" id="scheduleTask" name="task_description" 
                                   placeholder="Mô tả công việc cần thực hiện..." required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="scheduleStartDate" class="form-label">Ngày bắt đầu *</label>
                                    <input type="date" class="form-control" id="scheduleStartDate" name="start_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="scheduleEndDate" class="form-label">Ngày kết thúc *</label>
                                    <input type="date" class="form-control" id="scheduleEndDate" name="end_date" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="scheduleNotes" class="form-label">Ghi chú</label>
                            <textarea class="form-control" id="scheduleNotes" name="notes" rows="3" 
                                      placeholder="Thêm ghi chú hoặc hướng dẫn chi tiết..."></textarea>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Lưu ý:</strong> Lịch làm việc sẽ được tạo trực tiếp vào hệ thống và nhân viên có thể xem trong trang lịch làm việc của họ.
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" onclick="saveSchedule()">
                        <i class="fas fa-save"></i>
                        Tạo lịch làm việc
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        /* Xóa hoàn toàn backdrop của modal */
        .modal-backdrop {
            display: none !important;
        }
        
        /* Đảm bảo body không bị khóa khi modal mở */
        body.modal-open {
            overflow: auto !important;
            padding-right: 0 !important;
        }
        
        /* Tùy chọn: Thêm hiệu ứng overlay tinh tế nếu muốn có chỉ báo trực quan */
        .modal.show {
            background-color: rgba(0, 0, 0, 0.1);
        }
    </style>

    <script>
        // Ẩn overlay loading khi trang đã tải xong
        window.addEventListener('load', function() {
            const pageLoading = document.getElementById('pageLoading');
            if (pageLoading) {
                pageLoading.style.display = 'none';
            }
        });
        
        // Cũng ẩn overlay loading trên DOMContentLoaded như dự phòng
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const pageLoading = document.getElementById('pageLoading');
                if (pageLoading) {
                    pageLoading.style.display = 'none';
                }
            }, 1000); // Hide after 1 second as fallback
        });
        
        function assignStaff(planId) {
            document.getElementById('planId').value = planId;
            
            const modal = new bootstrap.Modal(document.getElementById('assignStaffModal'));
            modal.show();
        }

        function removeAssignment(planId) {
            if (confirm('Bạn có chắc muốn hủy phân công nhân viên này?')) {
                fetch('../src/controllers/staff-assignment.php', {
        method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=remove_assignment&plan_id=${planId}`
                })
                .then(response => response.json())
                .then(data => {
        if (data.success) {
                        alert('Hủy phân công thành công');
                        location.reload();
            } else {
                        alert('Lỗi: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Có lỗi xảy ra khi hủy phân công');
        });
    }
}

        function saveAssignment() {
            const form = document.getElementById('assignStaffForm');
            const formData = new FormData(form);
            formData.append('action', 'assign_staff');
            
            fetch('../../src/controllers/staff-assignment.php', {
        method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
            if (data.success) {
                    alert('Phân công nhân viên thành công');
                    location.reload();
            } else {
                    alert('Lỗi: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi phân công nhân viên');
            });
        }

        // Hiển thị thông tin nhân viên khi được chọn
        document.getElementById('staffSelect').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const staffInfo = document.getElementById('staffInfo');
            const staffDetails = document.getElementById('staffDetails');
            
            if (this.value) {
                const phone = selectedOption.getAttribute('data-phone');
                const status = selectedOption.getAttribute('data-status');
                const name = selectedOption.text.split(' - ')[0];
                
                staffDetails.innerHTML = `
                    <strong>Tên:</strong> ${name}<br>
                    <strong>Số điện thoại:</strong> ${phone}<br>
                    <strong>Trạng thái:</strong> ${status == 'Online' ? 'Đang online' : 'Offline'}
                `;
                staffInfo.style.display = 'block';
                } else {
                staffInfo.style.display = 'none';
            }
        });
        
        // Hiển thị modal tạo lịch
        function showCreateScheduleModal() {
            const modal = new bootstrap.Modal(document.getElementById('createScheduleModal'));
            modal.show();
        }
        
        // Hàm lưu lịch
        function saveSchedule() {
            const form = document.getElementById('createScheduleForm');
            const formData = new FormData(form);
            formData.append('action', 'create_assignment');
            
            // Validate các trường bắt buộc
            const staffId = formData.get('staff_id');
            const taskDescription = formData.get('task_description');
            const startDate = formData.get('start_date');
            const endDate = formData.get('end_date');
            
            if (!staffId || !taskDescription || !startDate || !endDate) {
                alert('Vui lòng điền đầy đủ thông tin bắt buộc');
                return;
            }
            
            // Validate ngày tháng
            if (new Date(startDate) > new Date(endDate)) {
                alert('Ngày kết thúc phải sau ngày bắt đầu');
                return;
            }
            
            fetch('../../src/controllers/staff-assignment.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Tạo lịch làm việc thành công!');
                    location.reload();
                } else {
                    alert('Lỗi: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi tạo lịch làm việc');
            });
        }
</script>
</body>
</html>