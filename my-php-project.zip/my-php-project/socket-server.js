const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);

// Cấu hình dựa trên môi trường cho cPanel/Passenger
// Khi Node.js app được mount tại /nodeapp trong cPanel, Socket.IO path là relative đến mount point đó
// Vì vậy chúng ta dùng '/socket.io' (relative), sẽ trở thành '/nodeapp/socket.io' trong production
// Tự động phát hiện môi trường: localhost dùng '', production (cPanel/Passenger) dùng '/nodeapp'
// Logic phát hiện: Nếu PORT là 3000 VÀ không có Passenger env vars => localhost, ngược lại => production
// Lưu ý: Passenger KHÔNG tự động strip prefix /nodeapp/, nên routes phải handle cả /nodeapp/ prefix
const isLocalhost = (process.env.PORT === '3000' || process.env.PORT === undefined) 
    && !process.env.PASSENGER_APP_ENV 
    && !process.env.PASSENGER_BASE_URI;
const APP_BASE_PATH = process.env.APP_BASE_PATH 
    ? process.env.APP_BASE_PATH.replace(/\/$/, '')
    : (isLocalhost ? '' : '/nodeapp'); // Rỗng cho localhost, '/nodeapp' cho production
const SOCKET_IO_PATH = '/socket.io'; // Luôn relative đến mount point
const CORS_ORIGINS = (process.env.CORS_ORIGINS || 'https://sukien.info.vn,http://localhost,http://localhost:80,http://localhost:3000,http://localhost:3001,http://127.0.0.1,http://127.0.0.1:80')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

const io = socketIo(server, {
    path: SOCKET_IO_PATH,
    cors: {
        origin: function (origin, callback) {
            // Cho phép requests không có origin (như mobile apps hoặc curl requests)
            if (!origin) {
                console.log('CORS: Cho phép request không có origin');
                return callback(null, true);
            }
            
            console.log('CORS: Đang kiểm tra origin:', origin);
            
            // Kiểm tra xem origin có trong danh sách cho phép không
            if (CORS_ORIGINS.includes(origin)) {
                console.log('CORS: Origin được cho phép (trong danh sách):', origin);
                callback(null, true);
            } else {
                // Cho phép localhost origins (cho development)
                if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
                    console.log('CORS: Origin được cho phép (localhost):', origin);
                    callback(null, true);
                } else {
                    console.log('CORS: Origin bị chặn:', origin);
                    callback(new Error('Not allowed by CORS'));
                }
            }
        },
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Lưu trữ users đã kết nối
const connectedUsers = new Map();
const adminUsers = new Set();
const userRooms = new Map(); // Map userId sang socket.id
const typingUsers = new Map(); // Map conversation_id sang typing users
const activeCalls = new Map(); // Map call_id sang {caller_id, receiver_id, call_type, status, startTime}
const userActiveCalls = new Map(); // Map userId sang call_id (để track user đang trong cuộc gọi nào)

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Debug middleware - Log tất cả requests để kiểm tra (có thể tắt sau khi debug xong)
app.use((req, res, next) => {
    console.log(`📥 Request: ${req.method} ${req.url}`);
    console.log(`📥 Original URL: ${req.originalUrl}`);
    console.log(`📥 Base URL: ${req.baseUrl}`);
    console.log(`📥 Path: ${req.path}`);
    next();
});

// Middleware để strip prefix /nodeapp/ nếu có (vì Passenger không tự động strip)
app.use((req, res, next) => {
    // Nếu request bắt đầu với /nodeapp/, strip nó đi
    if (req.url.startsWith('/nodeapp/')) {
        req.url = req.url.replace(/^\/nodeapp/, '');
        // Đảm bảo bắt đầu bằng /
        if (!req.url.startsWith('/')) {
            req.url = '/' + req.url;
        }
        console.log(`🔄 Stripped prefix, new URL: ${req.url}`);
    } else if (req.url === '/nodeapp') {
        req.url = '/';
        console.log(`🔄 Stripped prefix, new URL: ${req.url}`);
    }
    next();
});

// Routes
// Health check endpoint - Response đơn giản để tương thích với cPanel
// Middleware đã strip prefix /nodeapp/, nên route này sẽ handle cả / và /nodeapp/
app.get('/', (req, res) => {
    // Dùng text/html đơn giản không có charset để tương thích với cPanel
    res.type('text/html');
    res.status(200).send('Socket.IO server is running');
});

// Health check endpoint để debug
// Middleware đã strip prefix /nodeapp/, nên route này sẽ handle cả /health và /nodeapp/health
app.get('/health', (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        server: 'Socket.IO Server',
        path: SOCKET_IO_PATH,
        appBasePath: APP_BASE_PATH,
        environment: process.env.NODE_ENV || 'development',
        connectedUsers: connectedUsers.size,
        adminUsers: adminUsers.size,
        requestUrl: req.url,
        originalUrl: req.originalUrl,
        baseUrl: req.baseUrl,
        path: req.path
    });
});

// API endpoint cho PHP để emit Socket.IO events
// Middleware đã strip prefix /nodeapp/, nên route này sẽ handle cả /api/emit và /nodeapp/api/emit
app.post('/api/emit', express.json(), (req, res) => {
    try {
        const { event, data } = req.body;
        
        if (!event || !data) {
            return res.status(400).json({
                success: false,
                error: 'Missing event or data'
            });
        }
        
        console.log(`📡 PHP đang emit event: ${event}`, data);
        
        // Emit event đến các rooms phù hợp dựa trên loại event
        if (event === 'event_registered') {
            // Thông báo cho tất cả admins
            io.to('admin_room').emit('new_event_registration', {
                type: 'new_event',
                message: `Sự kiện mới: ${data.eventName} từ ${data.userName}`,
                eventId: data.eventId,
                userName: data.userName,
                eventName: data.eventName,
                timestamp: new Date()
            });
        } else if (event === 'event_status_updated') {
            // Thông báo cho user đã đăng ký sự kiện
            if (data.userId) {
                io.to(`user_${data.userId}`).emit('event_status_change', {
                    type: 'status_update',
                    message: `Sự kiện "${data.eventName}" đã được ${data.status === 'approved' ? 'duyệt' : 'từ chối'}`,
                    eventId: data.eventId,
                    eventName: data.eventName,
                    status: data.status,
                    adminName: data.adminName,
                    timestamp: new Date()
                });
            }
            
            // Thông báo cho admins
            io.to('admin_room').emit('admin_notification', {
                type: 'status_updated',
                message: `${data.adminName} đã ${data.status === 'approved' ? 'duyệt' : 'từ chối'} sự kiện "${data.eventName}"`,
                eventId: data.eventId,
                eventName: data.eventName,
                status: data.status,
                adminName: data.adminName,
                timestamp: new Date()
            });
        } else if (event === 'admin_comment_added') {
            // Thông báo cho user
            if (data.userId) {
                io.to(`user_${data.userId}`).emit('admin_comment', {
                    type: 'admin_comment',
                    message: `Admin đã thêm ghi chú cho sự kiện "${data.eventName}"`,
                    eventId: data.eventId,
                    eventName: data.eventName,
                    comment: data.comment,
                    adminName: data.adminName,
                    timestamp: new Date()
                });
            }
        } else if (event === 'system_notification') {
            // Broadcast đến tất cả users
            io.emit('system_notification', {
                type: data.type || 'info',
                message: data.message,
                timestamp: new Date()
            });
        } else {
            // Emit event tổng quát - broadcast đến tất cả
            io.emit(event, data);
        }
        
        res.json({
            success: true,
            message: `Event ${event} emitted successfully`
        });
    } catch (error) {
        console.error('Error emitting event:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Xử lý kết nối Socket.IO
io.on('connection', (socket) => {
    console.log('User đã kết nối:', socket.id);

    // Xử lý xác thực user
    socket.on('authenticate', (data) => {
        const { userId, userRole, userName } = data;
        
        // Lưu thông tin user
        connectedUsers.set(socket.id, {
            userId,
            userRole,
            userName,
            socketId: socket.id,
            connectedAt: new Date()
        });

        // Thêm vào admin set nếu user là admin
        if (userRole && [1, 2, 3, 4].includes(parseInt(userRole))) {
            adminUsers.add(socket.id);
            socket.join('admin_room');
            console.log('Admin user đã kết nối:', userName);
        }

        // Tham gia room riêng của user
        socket.join(`user_${userId}`);
        userRooms.set(userId, socket.id);
        
        // Cập nhật trạng thái online của user
        socket.emit('update_online_status', { userId, isOnline: true });
        
        // Gửi xác nhận
        socket.emit('authenticated', {
            success: true,
            message: 'Đã kết nối thành công',
            userId,
            userRole
        });

        // Thông báo cho admins về user mới kết nối
        if (adminUsers.has(socket.id)) {
            socket.to('admin_room').emit('admin_notification', {
                type: 'user_connected',
                message: `${userName} đã kết nối`,
                timestamp: new Date()
            });
        }
    });

    // Xử lý thông báo đăng ký sự kiện
    socket.on('event_registered', (data) => {
        const { eventName, userName, eventId } = data;
        
        // Thông báo cho tất cả admins
        io.to('admin_room').emit('new_event_registration', {
            type: 'new_event',
            message: `Sự kiện mới: ${eventName} từ ${userName}`,
            eventId,
            userName,
            eventName,
            timestamp: new Date()
        });

        console.log('New event registration:', eventName, 'from', userName);
    });

    // Xử lý cập nhật trạng thái sự kiện
    socket.on('event_status_updated', (data) => {
        const { eventId, eventName, status, userName, adminName } = data;
        
        // Thông báo cho user đã đăng ký sự kiện
        io.to(`user_${data.userId}`).emit('event_status_change', {
            type: 'status_update',
            message: `Sự kiện "${eventName}" đã được ${status === 'approved' ? 'duyệt' : 'từ chối'}`,
            eventId,
            eventName,
            status,
            adminName,
            timestamp: new Date()
        });

        // Thông báo cho admins
        io.to('admin_room').emit('admin_notification', {
            type: 'status_updated',
            message: `${adminName} đã ${status === 'approved' ? 'duyệt' : 'từ chối'} sự kiện "${eventName}"`,
            eventId,
            eventName,
            status,
            adminName,
            timestamp: new Date()
        });

        console.log('Event status updated:', eventName, 'to', status);
    });

    // Xử lý comment của admin
    socket.on('admin_comment_added', (data) => {
        const { eventId, eventName, comment, adminName, userId } = data;
        
        // Thông báo cho user
        io.to(`user_${userId}`).emit('admin_comment', {
            type: 'admin_comment',
            message: `Admin đã thêm ghi chú cho sự kiện "${eventName}"`,
            eventId,
            eventName,
            comment,
            adminName,
            timestamp: new Date()
        });

        console.log('Admin comment added to event:', eventName);
    });

    // Xử lý tham gia room của user
    socket.on('join_user_room', (data) => {
        const { userId } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo && userInfo.userId == userId) {
            socket.join(`user_${userId}`);
            userRooms.set(userId, socket.id);
            console.log(`User ${userId} joined their room`);
        }
    });

    // Xử lý tin nhắn mới - Tối ưu cho real-time sync
    socket.on('new_message', (data) => {
        const { conversation_id, message, user_id, user_name } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            console.log(`💬 ${userInfo.userName}: ${message}`);
            
            // Broadcast đến tất cả users trong conversation room
            io.to(`conversation_${conversation_id}`).emit('new_message', {
                conversation_id,
                message,
                user_id: userInfo.userId,
                user_name: userInfo.userName,
                timestamp: new Date()
            });
            
            console.log(`📢 Message broadcasted to conversation ${conversation_id}`);
        }
    });

    // Xử lý chỉ báo đang gõ - Tối ưu cho real-time sync
    socket.on('typing', (data) => {
        const { conversation_id, user_id, user_name } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            console.log(`⌨️ ${userInfo.userName} đang gõ trong conversation ${conversation_id}`);
            
            // Broadcast đến các participants trong conversation (trừ người gửi)
            socket.to(`conversation_${conversation_id}`).emit('typing', {
                conversation_id,
                user_id: userInfo.userId,
                user_name: userInfo.userName
            });
        }
    });

    // Xử lý dừng gõ - Tối ưu cho real-time sync
    socket.on('stop_typing', (data) => {
        const { conversation_id, user_id } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            console.log(`⏹️ ${userInfo.userName} đã dừng gõ trong conversation ${conversation_id}`);
            
            // Broadcast đến các participants trong conversation (trừ người gửi)
            socket.to(`conversation_${conversation_id}`).emit('stop_typing', {
                conversation_id,
                user_id: userInfo.userId
            });
        }
    });

    // Xử lý tham gia conversation - Tối ưu cho real-time sync
    socket.on('join_conversation', (data) => {
        const { conversation_id } = data;
        socket.join(`conversation_${conversation_id}`);
        console.log(`🟢 User đã tham gia conversation ${conversation_id}`);
    });

    // Xử lý rời conversation
    socket.on('leave_conversation', (data) => {
        const { conversation_id } = data;
        socket.leave(`conversation_${conversation_id}`);
        console.log(`🔴 User left conversation ${conversation_id}`);
    });

    // Xử lý broadcast message ngay lập tức
    socket.on('broadcast_message', (data) => {
        const { conversation_id, message, userId, timestamp } = data;
        console.log(`📢 Đang broadcast message trong conversation ${conversation_id}`);
        
        // Broadcast đến tất cả users trong conversation
        io.to(`conversation_${conversation_id}`).emit('broadcast_message', {
            conversation_id,
            message,
            userId,
            timestamp
        });
    });

    // Xử lý trạng thái đã đọc message
    socket.on('message_read', (data) => {
        const { conversation_id, message_id, user_id } = data;
        console.log(`👁️ Message ${message_id} đã được đọc bởi user ${user_id}`);
        
        // Thông báo cho các users khác trong conversation
        socket.to(`conversation_${conversation_id}`).emit('message_read', {
            conversation_id,
            message_id,
            user_id
        });
    });

    // Xử lý event messages đã được load
    socket.on('messages_loaded', (data) => {
        const { conversation_id, userId } = data;
        console.log(`📥 Messages đã được load cho user ${userId} trong conversation ${conversation_id}`);
        
        // Thông báo cho các users khác rằng messages đã được load
        socket.to(`conversation_${conversation_id}`).emit('messages_loaded', {
            conversation_id,
            userId
        });
    });

    // Xử lý real-time chat (tùy chọn)
    socket.on('chat_message', (data) => {
        const { message, userName, userRole } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            // Broadcast đến tất cả users
            io.emit('chat_message', {
                message,
                userName: userInfo.userName,
                userRole: userInfo.userRole,
                timestamp: new Date()
            });
        }
    });

    // Xử lý chỉ báo đang gõ
    socket.on('typing_start', (data) => {
        const userInfo = connectedUsers.get(socket.id);
        if (userInfo) {
            socket.broadcast.emit('user_typing', {
                userName: userInfo.userName,
                isTyping: true
            });
        }
    });

    socket.on('typing_stop', (data) => {
        const userInfo = connectedUsers.get(socket.id);
        if (userInfo) {
            socket.broadcast.emit('user_typing', {
                userName: userInfo.userName,
                isTyping: false
            });
        }
    });

    // Xử lý ngắt kết nối
    socket.on('disconnect', () => {
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            console.log('User đã ngắt kết nối:', userInfo.userName);
            
            // Xóa khỏi user rooms
            userRooms.delete(userInfo.userId);
            
            // Cập nhật trạng thái online của user
            socket.broadcast.emit('update_online_status', { 
                userId: userInfo.userId, 
                isOnline: false 
            });
            
            // Xóa khỏi admin set
            if (adminUsers.has(socket.id)) {
                adminUsers.delete(socket.id);
                
                // Thông báo cho các admins khác
                socket.to('admin_room').emit('admin_notification', {
                    type: 'admin_disconnected',
                    message: `${userInfo.userName} đã ngắt kết nối`,
                    timestamp: new Date()
                });
            }
            
            // Xóa khỏi connected users
            connectedUsers.delete(socket.id);
        }
    });

    // Xử lý các events cuộc gọi
    socket.on('call_initiated', (data) => {
        const { call_id, caller_id, receiver_id, call_type, conversation_id } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        console.log(`📞 Đã nhận event call initiated:`, {
            call_id,
            caller_id,
            receiver_id,
            call_type,
            conversation_id,
            socket_id: socket.id,
            user_info: userInfo
        });
        
        // Xác minh danh tính caller (kiểm tra tùy chọn - có thể xóa nếu không cần)
        if (userInfo && userInfo.userId != caller_id) {
            console.warn(`⚠️ Call được khởi tạo bởi user sai. Mong đợi ${caller_id}, nhận được ${userInfo.userId}`);
        }
        
        // ✅ Kiểm tra xem receiver có đang trong cuộc gọi khác không
        const receiverActiveCallId = userActiveCalls.get(receiver_id);
        if (receiverActiveCallId && receiverActiveCallId !== call_id) {
            const activeCall = activeCalls.get(receiverActiveCallId);
            if (activeCall && (activeCall.status === 'ringing' || activeCall.status === 'active')) {
                console.log(`⚠️ Receiver ${receiver_id} đang bận trong cuộc gọi ${receiverActiveCallId}`);
                
                // Lấy tên receiver từ connectedUsers
                let receiverName = 'Người dùng';
                for (let [socketId, user] of connectedUsers.entries()) {
                    if (user.userId == receiver_id) {
                        receiverName = user.userName || receiverName;
                        break;
                    }
                }
                
                // Thông báo cho caller rằng receiver đang bận
                io.to(`user_${caller_id}`).emit('call_busy', {
                    call_id,
                    receiver_id,
                    receiver_name: receiverName,
                    message: `${receiverName} đang trong cuộc gọi khác. Vui lòng thử lại sau.`,
                    busy_call_id: receiverActiveCallId
                });
                
                // Thông báo cho receiver về cuộc gọi bị từ chối do bận
                io.to(`user_${receiver_id}`).emit('call_notification', {
                    type: 'missed_call_busy',
                    call_id,
                    caller_id,
                    caller_name: userInfo ? (userInfo.userName || 'Người gọi') : 'Người gọi',
                    message: `Bạn có cuộc gọi từ ${userInfo ? (userInfo.userName || 'Người gọi') : 'Người gọi'} nhưng đang bận`,
                    timestamp: new Date()
                });
                
                return; // Không gửi call_initiated event
            }
        }
        
        // ✅ Kiểm tra xem caller có đang trong cuộc gọi khác không
        const callerActiveCallId = userActiveCalls.get(caller_id);
        if (callerActiveCallId && callerActiveCallId !== call_id) {
            const activeCall = activeCalls.get(callerActiveCallId);
            if (activeCall && (activeCall.status === 'ringing' || activeCall.status === 'active')) {
                console.log(`⚠️ Caller ${caller_id} đang trong cuộc gọi ${callerActiveCallId}, không thể gọi mới`);
                
                // Thông báo cho caller
                io.to(`user_${caller_id}`).emit('call_notification', {
                    type: 'cannot_call',
                    message: 'Bạn đang trong cuộc gọi khác. Vui lòng kết thúc cuộc gọi hiện tại trước.',
                    timestamp: new Date()
                });
                
                return; // Không gửi call_initiated event
            }
        }
        
        // ✅ Lưu thông tin cuộc gọi
        activeCalls.set(call_id, {
            caller_id,
            receiver_id,
            call_type,
            conversation_id,
            status: 'ringing',
            startTime: new Date()
        });
        userActiveCalls.set(receiver_id, call_id);
        userActiveCalls.set(caller_id, call_id);
        
        // ✅ Thông báo cho caller rằng cuộc gọi đang được xử lý
        io.to(`user_${caller_id}`).emit('call_notification', {
            type: 'calling',
            call_id,
            receiver_id,
            message: 'Đang gọi...',
            timestamp: new Date()
        });
        
        // Broadcast đến receiver qua user room (phương pháp chính)
        console.log(`📤 Đang broadcast call đến user_${receiver_id}`);
        io.to(`user_${receiver_id}`).emit('call_initiated', {
            call_id,
            caller_id,
            receiver_id,
            call_type,
            conversation_id,
            caller_name: userInfo ? (userInfo.userName || 'Người gọi') : 'Người gọi'
        });
        
        // Cũng broadcast đến conversation room để backup (nếu receiver đang trong conversation)
        if (conversation_id) {
            console.log(`📤 Đang broadcast call đến conversation_${conversation_id}`);
            io.to(`conversation_${conversation_id}`).emit('call_initiated', {
                call_id,
                caller_id,
                receiver_id,
                call_type,
                conversation_id,
                caller_name: userInfo ? (userInfo.userName || 'Người gọi') : 'Người gọi'
            });
        }
        
        // Fallback: broadcast đến tất cả sockets và để client filter (phương án cuối cùng)
        console.log(`📤 Đang broadcast call đến tất cả sockets như fallback`);
        socket.broadcast.emit('call_initiated', {
            call_id,
            caller_id,
            receiver_id,
            call_type,
            conversation_id,
            caller_name: userInfo ? (userInfo.userName || 'Người gọi') : 'Người gọi'
        });
        
        // ✅ Set timeout cho cuộc gọi (30 giây)
        setTimeout(() => {
            const call = activeCalls.get(call_id);
            if (call && call.status === 'ringing') {
                console.log(`⏰ Call ${call_id} timeout sau 30 giây`);
                
                // Cập nhật status
                call.status = 'timeout';
                activeCalls.set(call_id, call);
                
                // Xóa khỏi userActiveCalls
                userActiveCalls.delete(caller_id);
                userActiveCalls.delete(receiver_id);
                
                // Thông báo cho cả 2 bên
                io.to(`user_${caller_id}`).emit('call_timeout', {
                    call_id,
                    receiver_id,
                    message: 'Cuộc gọi không được trả lời sau 30 giây'
                });
                
                io.to(`user_${receiver_id}`).emit('call_timeout', {
                    call_id,
                    caller_id,
                    message: 'Cuộc gọi đã hết thời gian chờ'
                });
                
                // Xóa khỏi activeCalls sau 5 giây
                setTimeout(() => {
                    activeCalls.delete(call_id);
                }, 5000);
            }
        }, 30000); // 30 giây timeout
    });

    socket.on('call_accepted', (data) => {
        const { call_id, caller_id, receiver_id } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo && userInfo.userId == receiver_id) {
            console.log(`✅ Call đã được chấp nhận: ${call_id} bởi ${receiver_id}`);
            
            // ✅ Cập nhật status cuộc gọi
            const call = activeCalls.get(call_id);
            if (call) {
                call.status = 'active';
                activeCalls.set(call_id, call);
            }
            
            // ✅ Lấy tên receiver
            let receiverName = userInfo.userName || 'Người dùng';
            
            // Thông báo cho caller
            io.to(`user_${caller_id}`).emit('call_accepted', {
                call_id,
                caller_id,
                receiver_id,
                receiver_name: receiverName
            });
            
            // ✅ Thông báo cho receiver
            io.to(`user_${receiver_id}`).emit('call_notification', {
                type: 'call_active',
                call_id,
                caller_id,
                message: 'Cuộc gọi đã được kết nối',
                timestamp: new Date()
            });
        }
    });

    socket.on('call_rejected', (data) => {
        const { call_id, caller_id, receiver_id } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo && userInfo.userId == receiver_id) {
            console.log(`❌ Call đã bị từ chối: ${call_id} bởi ${receiver_id}`);
            
            // ✅ Cập nhật status cuộc gọi
            const call = activeCalls.get(call_id);
            if (call) {
                call.status = 'rejected';
                activeCalls.set(call_id, call);
            }
            
            // ✅ Xóa khỏi userActiveCalls
            userActiveCalls.delete(caller_id);
            userActiveCalls.delete(receiver_id);
            
            // ✅ Lấy tên receiver
            let receiverName = userInfo.userName || 'Người dùng';
            
            // Thông báo cho caller
            io.to(`user_${caller_id}`).emit('call_rejected', {
                call_id,
                caller_id,
                receiver_id,
                receiver_name: receiverName,
                message: `${receiverName} đã từ chối cuộc gọi`
            });
            
            // ✅ Thông báo cho receiver
            io.to(`user_${receiver_id}`).emit('call_notification', {
                type: 'call_rejected',
                call_id,
                caller_id,
                message: 'Bạn đã từ chối cuộc gọi',
                timestamp: new Date()
            });
            
            // ✅ Xóa khỏi activeCalls sau 5 giây
            setTimeout(() => {
                activeCalls.delete(call_id);
            }, 5000);
        }
    });

    socket.on('call_ended', (data) => {
        const { call_id, caller_id, receiver_id } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (userInfo) {
            console.log(`🔚 Call đã kết thúc: ${call_id}`);
            
            // ✅ Cập nhật status cuộc gọi
            const call = activeCalls.get(call_id);
            if (call) {
                call.status = 'ended';
                call.endTime = new Date();
                activeCalls.set(call_id, call);
            }
            
            // ✅ Xóa khỏi userActiveCalls
            userActiveCalls.delete(caller_id);
            userActiveCalls.delete(receiver_id);
            
            // ✅ Lấy tên người kết thúc cuộc gọi
            let endedByName = userInfo.userName || 'Người dùng';
            
            // Thông báo cho bên kia
            if (userInfo.userId == caller_id && receiver_id) {
                io.to(`user_${receiver_id}`).emit('call_ended', {
                    call_id,
                    caller_id,
                    receiver_id,
                    ended_by: caller_id,
                    ended_by_name: endedByName,
                    message: `${endedByName} đã kết thúc cuộc gọi`
                });
                
                // ✅ Thông báo cho caller
                io.to(`user_${caller_id}`).emit('call_notification', {
                    type: 'call_ended',
                    call_id,
                    message: 'Bạn đã kết thúc cuộc gọi',
                    timestamp: new Date()
                });
            } else if (userInfo.userId == receiver_id && caller_id) {
                io.to(`user_${caller_id}`).emit('call_ended', {
                    call_id,
                    caller_id,
                    receiver_id,
                    ended_by: receiver_id,
                    ended_by_name: endedByName,
                    message: `${endedByName} đã kết thúc cuộc gọi`
                });
                
                // ✅ Thông báo cho receiver
                io.to(`user_${receiver_id}`).emit('call_notification', {
                    type: 'call_ended',
                    call_id,
                    message: 'Bạn đã kết thúc cuộc gọi',
                    timestamp: new Date()
                });
            }
            
            // ✅ Xóa khỏi activeCalls sau 5 giây
            setTimeout(() => {
                activeCalls.delete(call_id);
            }, 5000);
        }
    });

    // Xử lý ping/pong để kiểm tra sức khỏe kết nối
    socket.on('ping', () => {
        socket.emit('pong');
    });
});

// Broadcast thông báo hệ thống
function broadcastSystemNotification(message, type = 'info') {
    io.emit('system_notification', {
        type,
        message,
        timestamp: new Date()
    });
}

// Lấy số lượng users đã kết nối
function getConnectedUsersCount() {
    return connectedUsers.size;
}

// Lấy số lượng admin users
function getAdminUsersCount() {
    return adminUsers.size;
}

// Khởi động server (Passenger cung cấp PORT); vẫn hoạt động ở localhost
const PORT = process.env.PORT || 3000;

// Log cấu hình khi khởi động
console.log('='.repeat(60));
console.log('Socket.IO Server Configuration:');
console.log('='.repeat(60));
console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
console.log(`APP_BASE_PATH: ${APP_BASE_PATH}`);
console.log(`SOCKET_IO_PATH: ${SOCKET_IO_PATH}`);
console.log(`Full Socket.IO URL: ${APP_BASE_PATH}${SOCKET_IO_PATH}`);
console.log(`CORS Origins: ${CORS_ORIGINS.join(', ')}`);
console.log(`Port: ${PORT}`);
console.log(`Node.js Version: ${process.version}`);
console.log('='.repeat(60));

// Khởi động server
// Passenger sẽ tự động cung cấp PORT qua biến môi trường
// Luôn gọi server.listen() để đảm bảo server được start (cả Passenger và localhost)
server.listen(PORT, () => {
    console.log('✅ Socket.IO server started successfully!');
    console.log(`📡 Server running on port: ${PORT}`);
    console.log(`🔗 Socket.IO path: ${SOCKET_IO_PATH}`);
    console.log(`📦 App Base Path: ${APP_BASE_PATH}`);
    console.log(`🌐 Full Socket.IO URL: ${APP_BASE_PATH}${SOCKET_IO_PATH}`);
    console.log(`📅 Server started at: ${new Date().toISOString()}`);
    console.log('='.repeat(60));
    console.log('🚀 Server is ready to accept connections!');
    console.log('='.repeat(60));
});

// Export app cho Passenger
// Passenger sẽ tự động tạo server từ app và mount vào /nodeapp
// Socket.IO đã được attach vào server (dòng 7), nên sẽ hoạt động khi app được mount
module.exports = app;
